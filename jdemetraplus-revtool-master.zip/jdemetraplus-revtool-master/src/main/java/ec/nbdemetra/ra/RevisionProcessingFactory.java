/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ec.nbdemetra.ra;

/**
 *
 * @author aresda
 */
public class RevisionProcessingFactory {

    public static final String INPUT = "input", TRANSFORM = "transform", REVISIONS = "revisions";        
    public static final int ERROR_INT = -1;
    public static final double ERROR_DOUBLE = Double.NaN;
}
