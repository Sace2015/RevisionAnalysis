/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ec.nbdemetra.ra.timeseries;

/**
 *
 * @author bennouha
 */
public enum VintageInputViewType {

    Vertical,
    Horizontal
}
