/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ec.nbdemetra.ra.descriptors;

/**
 *
 * @author aresda
 */
public class BasicAnalysisSpecUI { //implements IObjectDescriptor<BasicVintageSpecification> {

    /*final BasicVintageSpecification core;
    final boolean ro;
    
    public BasicAnalysisSpecUI(BasicVintageSpecification core, boolean ro) {
        this.ro = ro;
        this.core = core;
    }
    
    public BasicVintageSpecification getCore() {
        return core;
    }
       
    public String getDisplayName() {
        return "BasicAnalysisSpecUI";
    }
    
    public List<EnhancedPropertyDescriptor> getProperties() {
        ArrayList<EnhancedPropertyDescriptor> descs = new ArrayList<EnhancedPropertyDescriptor>();
        EnhancedPropertyDescriptor desc = spanDesc();
        if (desc != null) {
            descs.add(desc);
        }
        desc = transformDesc();
        if (desc != null) {
            descs.add(desc);
        }
        desc = inputviewDesc();
        if (desc != null) {
            descs.add(desc);
        }
        return descs;
    }
    
   */    
}
