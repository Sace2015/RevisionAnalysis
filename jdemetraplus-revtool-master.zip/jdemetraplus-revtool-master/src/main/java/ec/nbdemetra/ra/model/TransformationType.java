/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ec.nbdemetra.ra.model;

/**
 *
 * @author aresda
 */
public enum TransformationType {
    None,
    Log,
    Deltalog1,
    Deltalog4,
    DeltaLog12
}
