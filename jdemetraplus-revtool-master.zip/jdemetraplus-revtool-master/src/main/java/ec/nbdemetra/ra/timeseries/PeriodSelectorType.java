/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ec.nbdemetra.ra.timeseries;

/**
 *
 * @author aresda
 */
public enum PeriodSelectorType {
    All,
    /**
     * 
     */
    From,
    /**
     *
     */
    To,
    /**
     *
     */
    Between,
    /**
     * 
     */
    Last,
    /**
     * 
     */
    First,
    /**
     *
     */
    Excluding;
}
